var product=require('../models/product');
var mongoose=require('mongoose');
mongoose.connect('mongodb://localhost:27017/shopping',{useNewUrlParser:true});


var products=[
new product({
    imagepath:'https://www.91-img.com/pictures/128810-v4-oppo-r17-mobile-phone-large-1.jpg',
    title:'OPPO',
    description:'Awesome mobile!!!',
    price:20000
}),
new product({
    imagepath:'https://images.samsung.com/is/image/samsung/ae-feature-triple-the-fun-120457146?$FB_TYPE_A_MO_JPG$',
    title:'Samsung',
    description:'super cool..',
    price:30000
}),
new product({
    imagepath:'https://www.91-img.com/pictures/97744-v1-apple-iphone-7-mobile-phone-large-1.jpg',
    title:'Apple iphone',
    description:'No 1 mobile',
    price:60000
}),
new product({
    imagepath:'https://www.91-img.com/pictures/127444-v13-oneplus-6t-mobile-phone-large-1.jpg',
    title:'One plus 6T',
    description:'Now that is super awesome!',
    price:34999
}),
new product({
    imagepath:'https://hamariweb.com/images/MobilePhones/vivo-v11-pro-2.jpg',
    title:'Vivo v11',
    description:'Super !',
    price:53999
}),
new product({
    imagepath:'https://www.91-img.com/pictures/125417-v2-nokia-8-sirocco-mobile-phone-large-1.jpg',
    title:'Nokia 8 Sirocco',
    description:'Super hot!',
    price:34999
})
];

var done=0;
for(var i=0;i<products.length;i++)
{
    
    products[i].save(function(err,result){
       
        if(err)
    console.error(err);
        done++;
        if(done==products.length){
            exit();
        }
    });
}

function exit()
{
    mongoose.disconnect();
}
